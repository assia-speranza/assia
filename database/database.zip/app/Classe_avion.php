<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Classe_avion extends Model
{
    //












    
}
