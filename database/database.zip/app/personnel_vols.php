<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class personnel_vols extends Model
{
    //
}
