<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Escale extends Model
{
    //
    protected $primaryKey ='num_escale';





    
}
